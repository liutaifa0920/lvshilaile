<template>
  <div class="defaut-layout">
    <div class="layoutTitle">
      <img class="layoutLogo" src="img/layout/logoBlue.png" alt="律狮来了" />
      <ul class="layoutNav">
        <li @click="layoutNavClick(1)">
          <p>首页</p>
        </li>
        <li @click="layoutNavClick(2)">
          <p>服务领域</p>
        </li>
        <li @click="layoutNavClick(3)">
          <p>律师团队</p>
        </li>
        <li @click="layoutNavClick(4)">
          <p>新闻中心</p>
        </li>
        <li @click="layoutNavClick(5)">
          <p>关于我们</p>
        </li>
      </ul>
      <div class="layoutLoginBox">
        <img class="layoutLoginTip" src="img/layout/铃铛.png" alt="消息通知" />
        <div class="layoutLoginBlock">
          <p>登录</p>
          <div class="layoutLoginMid"></div>
          <p>注册</p>
        </div>
      </div>
    </div>
    <router-view />
  </div>
</template>

<script>
export default {
  name: "defaut-layout",
  data() {
    return {};
  },
  methods: {}
};
</script>
<style scoped>
.defaut-layout {
  width: 100%;
}
/* ---------------------- Nav ------------------- */
.layoutTitle {
  width: 100%;
  height: 60px;
  background-color: #2971de;
  color: white;
  display: flex;
  justify-content: space-between;
  align-items: center;
}
/* logo */
.layoutLogo {
  width: 123px;
  height: 40px;
  background-color: #ffffff;
  margin-left: 50px;
}
/* topNav */
.layoutNav {
  height: 60px;
  display: flex;
  align-items: center;
  font-size: 14px;
}
.layoutNav > li {
  width: 100px;
  height: 60px;
  line-height: 60px;
  text-align: center;
  transition: 0.3s;
  cursor: pointer;
}
.layoutNav > li:hover {
  background-color: #4e88df;
  transition: 0.3s;
}
.layoutNavAction {
  background-color: #4e88df;
  transition: 0.3s;
}
/* topRight */
.layoutLoginBox {
  width: 125px;
  margin-right: 51px;
  display: flex;
  align-items: center;
}
/* topTip */
.layoutLoginTip {
  width: 18px;
  height: 20px;
  margin-right: 23px;
  cursor: pointer;
}
/* topLogin */
.layoutLoginBlock {
  font-size: 14px;
  height: 16px;
  line-height: 16px;
  width: 86px;
  display: flex;
  justify-content: space-around;
}
.layoutLoginBlock > p {
  cursor: pointer;
}
.layoutLoginMid {
  height: 16px;
  width: 2px;
  background-color: white;
}
</style>
