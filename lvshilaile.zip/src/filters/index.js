// 全局过滤器文件

// 转string类型
export function toString(val) {
  return val.toString();
}
