const getters = {
  test: state => state.home.test
};

export default getters;
