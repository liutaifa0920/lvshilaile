// vant组件按需引入
import Vue from "vue";

import element from "element-ui";

Vue
    .use(element)
    ;
