<template>
  <div class="home">
    <!-- swipe -->
    <div class="homeSwipe">
      <el-carousel ref="carousel" indicator-position="none" arrow="never">
        <el-carousel-item v-for="item in 4" :key="item">
          <img
            class="homeSwipeImg"
            src="img/layout/fc16df52807a20cdfafbd34b59c6f3bb104748.jpg"
            alt="swipe"
          />
        </el-carousel-item>
      </el-carousel>
      <div class="homwSwipeBtn swipeLeft" @click="swipePrev">
        <img src="img/home/向左箭头.png" alt="上一张" />
      </div>
      <div class="homwSwipeBtn swipeRight" @click="swipeNext">
        <img src="img/home/向右箭头.png" alt="下一张" />
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {};
  },
  methods: {
    // 轮播上下页
    swipePrev() {
      this.$refs.carousel.prev();
    },
    swipeNext() {
      this.$refs.carousel.next();
    }
  }
};
</script>

<style scoped>
.el-carousel {
  height: 450px;
}
.el-carousel__item,
.el-carousel__mask {
  height: 450px;
}

/* swipe */
.homeSwipe {
  position: relative;
}
.homeSwipeImg {
  width: 100%;
  height: 450px;
}
.homwSwipeBtn {
  width: 20px;
  height: 38px;
  background-color: #8f8f8f90;
  z-index: 500;
  position: absolute;
  top: 206px;
}
.homwSwipeBtn > img {
  width: 20px;
  height: 38px;
  opacity: 1;
}
</style>
